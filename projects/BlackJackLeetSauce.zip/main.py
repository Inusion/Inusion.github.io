import random
from random import randrange
import replit
replit.clear();
#While Breaks
WhileBreakPlayGame = 0;
WhileBreakCheckWin = 0;
WhileBreakHit3 = 0;
WhileBreakHit4 = 0;
#Currency (Optional)
MoneyValue = 500;
MoneyString =  '$' + str(MoneyValue);
YourMoney = [MoneyValue, MoneyString];
DealerBet = 0;
Bet = 0;
#Values (Reference)
SoftKeepD = 0;
AceValue = [1, 11];
TwoValue = 2;
ThreeValue = 3;
FourValue = 4;
FiveValue = 5;
SixValue = 6;
SevenValue = 7;
EightValue = 8;
NineValue = 9;
TenValue = 10;
JackValue = 10
QueenValue = 10;
KingValue = 10;
#Cards:
AcesTFD = 0;
AcesTFY = 0;
Aces11TFY = 0;
Aces11TFD = 0;
Card1DealerH = '';
Card2Dealer = '';
Card3Dealer = '';
Card4Dealer = '';
Card5Dealer = '';
CardYou1H = '';
CardYou2 = '';
CardYou3 = '';
CardYou4 = '';
CardYou5 = '';
DealerTotal = 0;
YouTotal = 0;
#Diamonds Ace - King
DA = [AceValue, '1♦'];
D2 = [TwoValue, '2♦'];
D3 = [ThreeValue, '3♦'];
D4 = [FourValue, '4♦'];
D5 = [FiveValue, '5♦'];
D6 = [SixValue, '6♦'];
D7 = [SevenValue, '7♦'];
D8 = [EightValue, '8♦'];
D9 = [NineValue, '9♦'];
D10 = [TenValue, '10♦'];
DJ = [JackValue, 'J♦'];
DQ = [QueenValue, 'Q♦'];
DK = [KingValue, 'K♦'];
#Spades  A-K
SA = [AceValue, 'A♠'];
S2 = [TwoValue, '2♠'];
S3 = [ThreeValue, '3♠'];
S4 = [FourValue, '4♠'];
S5 = [FiveValue, '5♠'];
S6 = [SixValue, '6♠'];
S7 = [SevenValue, '7♠'];
S8 = [EightValue, '8♠'];
S9 = [NineValue, '9♠'];
S10 = [TenValue, '10♠'];
SJ = [JackValue, '10♠'];
SQ = [QueenValue, '10♠'];
SK = [KingValue, '10♠'];
#Hearts  A-K
HA = [AceValue, 'A♥'];
H2 = [TwoValue, '2♥'];
H3 = [ThreeValue, '3♥'];
H4 = [FourValue, '4♥'];
H5 = [FiveValue, '5♥'];
H6 = [SixValue, '6♥'];
H7 = [SevenValue, '7♥'];
H8 = [EightValue, '8♥'];
H9 = [NineValue, '9♥'];
H10 = [TenValue, '10♥'];
HJ = [JackValue, 'J♥'];
HQ = [QueenValue, 'Q♥'];
HK = [KingValue, 'K♥'];
#Clubs  A-K
CA = [AceValue, 'A♣'];
C2 = [TwoValue, '2♣'];
C3 = [ThreeValue, '3♣'];
C4 = [FourValue, '4♣'];
C5 = [FiveValue, '5♣'];
C6 = [SixValue, '6♣'];
C7 = [SevenValue, '7♣'];
C8 = [EightValue, '8♣'];
C9 = [NineValue, '9♣'];
C10 =[TenValue, '10♣'];
CJ = [JackValue, 'J♣'];
CQ = [QueenValue, 'Q♣'];
CK = [KingValue, 'K♣'];
#Deck
Deck = [DA, D2, D3, D4, D5, D6, D7, D8, D9, D10, DJ, DQ, DK, SA, S2, S3, S4, S5, S6, S7, S8, S9, S10, SJ, SQ, SK, HA, H2, H3, H4, H5, H6, H7, H8, H9, H10, HJ, HQ, HK, CA, C2, C3, C4, C5, C6, C7, C8, C9, C10, CJ, CQ, CK];
DeckInUse = Deck;
DeckSize = 52;
#Intro/First Line of Code
def Welcome():
  replit.clear();
  print('Welcome to the Python BlackJackLeetSauce game!');
  print('To begin, type *play*');
  print('');
  print('For help, type *help*');
  print('');
  print("When You're done, type *exit* to exit the game");
  print('');
Welcome();
def resetDeck():
  global DA;
  global D2;
  global D3;
  global D4;
  global D5;
  global D6;
  global D7;
  global D8;
  global D9;
  global D10;
  global DJ;
  global DQ;
  global DK;
  global SA;
  global S2;
  global S3;
  global S4;
  global S5;
  global S6;
  global S7;
  global S8;
  global S9;
  global S10;
  global SJ;
  global SQ;
  global SK;
  global HA;
  global H2;
  global H3;
  global H4;
  global H5;
  global H6;
  global H7;
  global H8;
  global H9;
  global H10;
  global HJ;
  global HQ;
  global HK;
  global CA;
  global C2;
  global C3;
  global C4;
  global C5;
  global C6;
  global C7;
  global C8;
  global C9;
  global C10;
  global CJ;
  global CQ;
  global CK;
  global DeckInUse;
  global Deck;
  global DeckSize;
  #Diamonds A-K
  DA = [AceValue, 'A♦'];
  D2 = [TwoValue, '2♦'];
  D3 = [ThreeValue, '3♦'];
  D4 = [FourValue, '4♦'];
  D5 = [FiveValue, '5♦'];
  D6 = [SixValue, '6♦'];
  D7 = [SevenValue, '7♦'];
  D8 = [EightValue, '8♦'];
  D9 = [NineValue, '9♦'];
  D10 = [TenValue, '10♦'];
  DJ = [JackValue, 'J♦'];
  DQ = [QueenValue, 'Q♦'];
  DK = [KingValue, 'K♦'];
  #Spades  A-K
  SA = [AceValue, 'A♠'];
  S2 = [TwoValue, '2♠'];
  S3 = [ThreeValue, '3♠'];
  S4 = [FourValue, '4♠'];
  S5 = [FiveValue, '5♠'];
  S6 = [SixValue, '6♠'];
  S7 = [SevenValue, '7♠'];
  S8 = [EightValue, '8♠'];
  S9 = [NineValue, '9♠'];
  S10 = [TenValue, '10♠'];
  SJ = [JackValue, '10♠'];
  SQ = [QueenValue, '10♠'];
  SK = [KingValue, '10♠'];
  #Hearts  A-K
  HA = [AceValue, 'A♥'];
  H2 = [TwoValue, '2♥'];
  H3 = [ThreeValue, '3♥'];
  H4 = [FourValue, '4♥'];
  H5 = [FiveValue, '5♥'];
  H6 = [SixValue, '6♥'];
  H7 = [SevenValue, '7♥'];
  H8 = [EightValue, '8♥'];
  H9 = [NineValue, '9♥'];
  H10 = [TenValue, '10♥'];
  HJ = [JackValue, 'J♥'];
  HQ = [QueenValue, 'Q♥'];
  HK = [KingValue, 'K♥'];
  #Clubs  A-K
  CA = [AceValue, 'A♣'];
  C2 = [TwoValue, '2♣'];
  C3 = [ThreeValue, '3♣'];
  C4 = [FourValue, '4♣'];
  C5 = [FiveValue, '5♣'];
  C6 = [SixValue, '6♣'];
  C7 = [SevenValue, '7♣'];
  C8 = [EightValue, '8♣'];
  C9 = [NineValue, '9♣'];
  C10 =[TenValue, '10♣'];
  CJ = [JackValue, 'J♣'];
  CQ = [QueenValue, 'Q♣'];
  CK = [KingValue, 'K♣'];
  #Deck
  Deck = [DA, D2, D3, D4, D5, D6, D7, D8, D9, D10, DJ, DQ, DK, SA, S2, S3, S4, S5, S6, S7, S8, S9, S10, SJ, SQ, SK, HA, H2, H3, H4, H5, H6, H7, H8, H9, H10, HJ, HQ, HK, CA, C2, C3, C4, C5, C6, C7, C8, C9, C10, CJ, CQ, CK];
  DeckInUse = Deck;
  DeckSize = 52;
  #Play Command
def PlayGame():
  replit.clear();
  global SoftKeepD;
  global Aces11TFD;
  global Aces11TFY;
  global WhileBreakPlayGame;
  global WhileBreakHit3;
  global WhileBreakHit4;
  global WhileBreakCheckWin;
  global DeckInUse;
  global DeckSize;
  global AceValue;
  global Card1YouH;
  global Card2You;
  global Card3You;
  global Card4You;
  global Card5You;
  global YouTotal;
  global Card1DealerH;
  global Card2Dealer;
  global Card3Dealer;
  global Card4Dealer;
  global Card5Dealer;
  global DealerTotal;
  global AcesTFD;
  global AcesTFY;
  global YourMoney;
  global DealerBet
  global Bet
  if YourMoney[0] == 0:
    print("You're broke, and cannot play, please stop.");
  else:
    Bet = 0;
    WhileBreakPlayGame = 0;
    Card1DealerH = '';
    Card2Dealer = '';
    Card3Dealer = '';
    Card4Dealer = '';
    Card5Dealer = '';
    CardYou1H = '';
    CardYou2 = '';
    CardYou3 = '';
    CardYou4 = '';
    CardYou5 = '';
    DealerTotal = 0;
    YouTotal = 0;
    AcesTFY = 0;
    AcesTFD = 0;
    Aces11TFD = 0;
    Aces11TFY = 0;
    print('');
    no = 'no';
    while 'yes' != no:
      try:
        Bet = int(input('You have ' + YourMoney[1] + '. How much would you like to bet? - '));
      except:
        print('');
        print('Please only use integer Values.');
        print('');
      if Bet <= 0 or Bet > YourMoney[0]:
        print('');
        print('Please only bet within your budget.');
        print('');
      else:
        if Bet % 2 == 1:
          DealerBet1 = Bet // 2;
          DealerBet = DealerBet1 + 1;
        else:
          DealerBet = Bet // 2;
        YourMoney[0] = YourMoney[0] - Bet;
        YourMoney[1] = '$' + str(YourMoney[0]);
        no = 'yes';
        break;
    print('');
    print('You bet $' + str(Bet) + ' - You will win 1.5x What you bet.');
    if DeckSize <= 10:
      resetDeck();
      print('');
      print('The Deck is running low on cards, the Dealer Shuffles the played cards back into the deck.');
      print('');
    state = '';
    card1DIndexH = randrange(0, DeckSize);
    Card1DealerH = DeckInUse[card1DIndexH];
    DeckSize = DeckSize - 1; 
    del DeckInUse[card1DIndexH];
    card2DIndex = randrange(0, DeckSize);
    Card2Dealer = DeckInUse[card2DIndex];
    DeckSize = DeckSize - 1;
    del DeckInUse[card2DIndex];
    if Card1DealerH[0] == AceValue and Card2Dealer[0] != AceValue:
      DealerTotal = Card1DealerH[0][1] + Card2Dealer[0];
      AcesTFD = 1;
      Aces11TFD = 1;
    elif Card1DealerH[0] != AceValue and Card2Dealer[0] == AceValue:
      DealerTotal = Card1DealerH[0] + Card2Dealer[0][1];
      AcesTFD = 1;
      Aces11TFD = 1;
    elif Card1DealerH[0] == AceValue and Card2Dealer[0] == AceValue:
      AcesTFD = 1;
      DealerTotal = Card1DealerH[0][0] + Card2Dealer[0][1];
      Aces11TFD = 1;
    else:
      DealerTotal = int(Card1DealerH[0]) + int(Card2Dealer[0])
    card1YIndexS = randrange(0, DeckSize);
    Card1YouH = DeckInUse[card1YIndexS];
    DeckSize = DeckSize - 1;
    del DeckInUse[card1YIndexS];
    card2YIndexH = randrange(0, DeckSize);
    Card2You = DeckInUse[card2YIndexH];
    DeckSize = DeckSize - 1;
    del DeckInUse[card2YIndexH]
    if Card1YouH[0] == AceValue and Card2You[0] != AceValue:
      AcesTFY = 1;
      Aces11TFY = 1;
      YouTotal = Card1YouH[0][1] + Card2You[0];
    elif Card1YouH[0] != AceValue and Card2You[0] == AceValue:
      AcesTFY = 1;
      Aces11TFY = 1;
      YouTotal = Card1YouH[0] + Card2You[0][1];
    elif Card1YouH[0] == AceValue and Card2You[0] == AceValue:
      AcesTFY = 1;
      Aces11TFY = 1;
      YouTotal = Card1YouH[0][0] + Card2You[0][1];
    else:
      YouTotal = int(Card1YouH[0]) + int(Card2You[0]);
    print('');
    print('-=--=--=--=--=--=--=--=-');
    print('');
    print('The Dealer has 1 Hidden Card');
    print(Card2Dealer[1] + " - Dealer's Shown Card");
    print('');
    print(Card1YouH[1] + ' - Your Hidden Card');
    print(Card2You[1] + ' - Your Shown Card');
    if DealerTotal == 17 and Aces11TFD == 1:
      SoftKeepD == 1;
    else:
      SoftKeepD == 0;
    if DealerTotal == 21 and YouTotal != 21:
      print('');
      print('-=--=--=--=--=--=--=--=-');
      print('');
      print("Dealer Wins, they got BlackJack! Dealer's hidden card was - " + Card1DealerH[1]);
    elif DealerTotal == 21 and YouTotal == 21:
      print("You and the dealer both got BlackJack - " + Card1DealerH[1]);
      YourMoney[0] = YourMoney[0] + Bet;
      YourMoney[1] = "$" + str(YourMoney[0]);
      print('');
      print('Your Current Balance is now ' + YourMoney[1]);
      print('')
    elif YouTotal == 21 and DealerTotal != 21:
      print("You got Blackjack, you Win! Dealer's Hidden Card Was - " + Card1DealerH[1]);
      YourMoney[0] = YourMoney[0] + Bet + DealerBet;
      YourMoney[1] = "$" + str(YourMoney[0]);
      print('');
      print('Your Current Balance is now ' + YourMoney[1]);
      print('');
    else:
      WhileBreakHit3 = 1;
      WhileBreakHit4 = 1;
      WhileBreakCheckWin = 1;
      WhileBreakPlayGame = 0;
      while state != 'hit' or state != 'stand':
        if WhileBreakPlayGame == 1:
          break;
        else: 
          HitStand = input('*hit* or *stand*: ');
          if HitStand == 'hit':
            WhileBreakPlayGame = 1;
            state = 'hit';
            hit3();
          elif HitStand == 'stand':
            WhileBreakPlayGame = 1;
            state = 'stand';
            CheckWin();
          elif HitStand == 'help':
            help();
          elif HitStand == 'exit':
            break;
          else:
            print('idiot');
def hit3():
  print('');
  print("-=--=--=--=--=--=--=--=-");
  print('');
  global WhileBreakPlayGame;
  global WhileBreakHit3;
  global WhileBreakHit4;
  global WhileBreakCheckWin;
  global DeckInUse;
  global DeckSize;
  global AceValue;
  global Card3You;
  global YouTotal;
  global AcesTFY;
  global Aces11TFY;
  You3Index = randrange(0, DeckSize);
  DeckSize = DeckSize - 1;
  Card3You = DeckInUse[You3Index];
  del DeckInUse[You3Index];
  if Card3You[0] == AceValue and AcesTFY == 1:
    YouTotal = YouTotal + Card3You[0][0];
  elif Card3You[0] == AceValue and AcesTFY == 0:
    AcesTFY = 1;
    if YouTotal + Card3You[0][1] > 21:
      YouTotal = YouTotal + Card3You[0][0];
    elif YouTotal + Card3You[0][1] <= 21:
      YouTotal = YouTotal + Card3You[0][1];
      Aces11TFY = 1;
  else:
    YouTotal = YouTotal + Card3You[0];
  print('Your Next Card is - ' + Card3You[1]);
  WhileKeep2 = 0;
  if YouTotal > 21 and Aces11TFY == 1:
    YouTotal == YouTotal - 10;
    Aces11TFY = 0;
  if YouTotal > 21:
    CheckWin();
  else:
    WhileBreakHit3 = 0;
    WhileBreakHit4 = 1;
    WhileBreakCheckWin = 1;
    WhileBreakPlayGame = 1;
    while WhileKeep2 != 1:
      if WhileBreakHit3 == 1:
        break;
      else:
        HitAgain = input('Would You like to Hit Again? - *hit* or *stand* - ');
        if HitAgain == 'hit':
          WhileBreakHit3 = 1;
          hit4();
        elif HitAgain == 'stand':
          WhileBreakHit3 = 1;
          CheckWin();
        elif HitAgain == 'help':
          help();
        elif HitAgain == 'exit':
          break;
        else:
          print('Idiot.');
        break;
def hit4():
  print('');
  print("-=--=--=--=--=--=--=--=-");
  print('');
  global WhileBreakPlayGame;
  global WhileBreakHit3;
  global WhileBreakHit4;
  global WhileBreakCheckWin;
  global DeckInUse;
  global DeckSize;
  global AceValue;
  global Card4You;
  global YouTotal;
  global AcesTFY;
  global Aces11TFY;
  You4Index = randrange(0, DeckSize);
  DeckSize = DeckSize - 1;
  Card4You = DeckInUse[You4Index];
  del DeckInUse[You4Index];
  if Card4You[0] == AceValue and AcesTFY == 1:
    YouTotal = YouTotal + Card4You[0][0];
  elif Card4You[0] == AceValue and AcesTFY == 0:
    AcesTFY = 1;
    if YouTotal + Card4You[0][1] > 21:
      YouTotal = YouTotal + Card4You[0][0];
    elif YouTotal + Card4You[0][1] <= 21:
      YouTotal = YouTotal + Card4You[0][1];
      Aces11TFY = 1;
  else:
    YouTotal = YouTotal + Card4You[0]
  print('Your Next Card is - ' + Card4You[1]);
  WhileKeep3 = 0;
  if YouTotal > 21 and Aces11TFY == 1:
    Aces11TFY = 0;
    YouTotal == YouTotal - 10;
  if YouTotal > 21:
    CheckWin();
  else:
    WhileBreakHit3 = 1;
    WhileBreakHit4 = 0;
    WhileBreakCheckWin = 1;
    WhileBreakPlayGame = 1;
    while WhileKeep3 != 1:
      if WhileBreakHit4 == 1:
        break;
      else:
        HitAgain = input('Would You like to Hit Again? - *hit* or *stand* - ');
        if HitAgain == 'hit':
          WhileBreakHit4 = 1;
          hit5();
        elif HitAgain == 'stand':
          WhileBreakHit4 = 1;
          CheckWin();
        elif HitAgain == 'help':
          help();
        elif HitAgain == 'exit':
          break;
        else:
          print('Idiot.');
        break;
def hit5():
  print('');
  print("-=--=--=--=--=--=--=--=-");
  print('');
  global DeckInUse;
  global DeckSize;
  global AceValue;
  global Card5You;
  global YouTotal;
  global AcesTFY;
  You5Index = randrange(0, DeckSize);
  DeckSize = DeckSize - 1;
  Card5You = DeckInUse[You5Index];
  del DeckInUse[You5Index];
  if Card5You[0] == AceValue and AcesTFY == 1:
    YouTotal = YouTotal + Card5You[0][0];
  elif Card5You[0] == AceValue and AcesTFY == 0:
    AcesTFY = 1;
    if YouTotal + Card5You[0][1] > 21:
      YouTotal = YouTotal + Card5You[0][0];
    elif YouTotal + Card5You[0][1] <= 21:
      YouTotal = YouTotal + Card5You[0][1];
      Aces11TFY = 1;
  else:
    YouTotal = YouTotal + Card5You[0]
  print('Your Next Card is - ' + Card5You[1]);
  if YouTotal > 21 and Aces11TFY == 1:
    Aces11TFY = 0;
    YouTotal == YouTotal - 10;
  CheckWin();
def DealerHit():
  global DeckInUse;
  global DeckSize;
  global AceValue;
  global Card1DealerH;
  global Card2Dealer;
  global Card3Dealer;
  global Card4Dealer;
  global Card5Dealer;
  global DealerTotal;
  global AcesTFD;
  global Aces11TFD;
  global SoftKeepD;
  DealerIndex3 = randrange(0, DeckSize);
  DeckSize = DeckSize - 1;
  Card3Dealer = DeckInUse[DealerIndex3];
  del DeckInUse[DealerIndex3];
  if Card3Dealer[0] == AceValue and AcesTFD == 1:
    DealerTotal == DealerTotal + Card3Dealer[0][0];
  elif Card3Dealer[0] == AceValue and AcesTFD == 0:
    AcesTFD = 1;
    if DealerTotal + Card3Dealer[0][1] > 21:
      DealerTotal = DealerTotal + Card3Dealer[0][0];
    elif DealerTotal + Card3Dealer[0][1] <= 21:
      DealerTotal = DealerTotal + Card3Dealer[0][1];
      Aces11TFD = 1;
  else:
    DealerTotal = DealerTotal + Card3Dealer[0];
  print('The Dealer Hits - ' + Card3Dealer[1]);
  if DealerTotal < 17:
    DealerIndex4 = randrange(0, DeckSize);
    DeckSize = DeckSize - 1;
    Card4Dealer = DeckInUse[DealerIndex4];
    del DeckInUse[DealerIndex4];
    if Card4Dealer[0] == AceValue and AcesTFD == 1:
      DealerTotal == DealerTotal + Card4Dealer[0][0];
    elif Card4Dealer[0] == AceValue and AcesTFD == 0:
      AcesTFD = 1;
      if DealerTotal + Card4Dealer[0][1] > 21:
        DealerTotal = DealerTotal + Card4Dealer[0][0];
      elif DealerTotal + Card4Dealer[0][1] <= 21:
        DealerTotal = DealerTotal + Card4Dealer[0][1];
        Aces11TFD = 1;
    else:
      DealerTotal = DealerTotal + Card4Dealer[0];
    print('The Dealer Hits Again - ' + Card4Dealer[1]);
    if DealerTotal == 17 and Aces11TFD == 1:
      SoftKeepD = 1;
    else:
      SoftKeepD = 0;
    if DealerTotal < 17 or SoftKeepD == 1:
      DealerIndex5 = randrange(0, DeckSize);
      DeckSize = DeckSize - 1;
      Card5Dealer = DeckInUse[DealerIndex5];
      del DeckInUse[DealerIndex5];
      if Card5Dealer[0] == AceValue and AcesTFD == 1:
        DealerTotal == DealerTotal + Card5Dealer[0][0];
      elif Card5Dealer[0] == AceValue and AcesTFD == 0:
        AcesTFD = 1
        if DealerTotal + Card5Dealer[0][1] > 21:
          DealerTotal = DealerTotal + Card5Dealer[0][0];
        elif DealerTotal + Card5Dealer[0][1] <= 21:
          DealerTotal = DealerTotal + Card4Dealer[0][1];
          Aces11TFD = 1;
      else:
        DealerTotal = DealerTotal + Card5Dealer[0];
      print('The Dealer Hits Yet Again - ' + Card5Dealer[1]);
      CheckWin();
    else:
      CheckWin();
  else:
    CheckWin();
def CheckWin():
  print('');
  print("-=--=--=--=--=--=--=--=-");
  print('');
  global WhileBreakPlayGame;
  global WhileBreakHit3;
  global WhileBreakHit4;
  global WhileBreakCheckWin;
  global DealerTotal;
  global YouTotal;
  global Card1DealerH;
  global Bet;
  global YourMoney;
  global Dealerbet;
  global Aces11TFD;
  global SoftKeepD;
  global Aces11TFY;
  if DealerTotal == 17 and Aces11TFD == 1:
    SoftKeepD = 1;
  if DealerTotal > 21 and Aces11TFD == 1:
    DealerTotal = DealerTotal - 10;
    Aces11TFD = 0;
  if YouTotal > 21 and Aces11TFY == 1:
    YouTotal == YouTotal - 10;
    Aces11TFY = 0;
  WhileBreakCheckWin = 0;
  if YouTotal > 21:
    print("Dealer Wins, You Busted! - The Dealer's Hiddden Card was - " + Card1DealerH[1]);
    print('');
    print('Your Current Balance is now ' + YourMoney[1]);
    print('');
  elif DealerTotal > 21 and YouTotal <= 21:
    print("You Win, Dealer Busted! - The Dealer's Hidden Card was - " + Card1DealerH[1]);
    YourMoney[0] = YourMoney[0] + Bet + DealerBet;
    YourMoney[1] = '$' + str(YourMoney[0]);
    print('');
    print('Your Current Balance is now ' + YourMoney[1]);
    print('');
  elif DealerTotal == 21 and DealerTotal > YouTotal:
    print("Dealer Wins! - The Dealer's Hiddden Card was - " + Card1DealerH[1]);
    print('');
    print('Your Current Balance is now ' + YourMoney[1]);
    print('');
  elif DealerTotal < 17 or SoftKeepD == 1:
    DealerHit();
  elif YouTotal == 21 and YouTotal > DealerTotal:
    print("You Win! - The Dealer's Hiddden Card was - " + Card1DealerH[1]);
    YourMoney[0] = YourMoney[0] + Bet + DealerBet;
    YourMoney[1] = '$' + str(YourMoney[0]);
    print('');
    print('Your Current Balance is now ' + YourMoney[1]);
    print('');
  elif DealerTotal >= 17 and DealerTotal > YouTotal:
    print("Dealer Wins! - The Dealer's Hiddden Card was - " + Card1DealerH[1]);
    print('');
    print('Your Current Balance is now ' + YourMoney[1]);
    print('');
  elif DealerTotal >= 17 and DealerTotal < YouTotal:
    print("You Win! - The Dealer's Hidden Card was - " + Card1DealerH[1]);
    YourMoney[0] = YourMoney[0] + Bet + DealerBet;
    YourMoney[1] = '$' + str(YourMoney[0]);
    print('');
    print('Your Current Balance is now ' + YourMoney[1]);
    print('');
  elif DealerTotal == YouTotal:
    print("Push! You keep your bet! - The Dealer's Hiddden Card was - " + Card1DealerH[1]);
    YourMoney[0] = YourMoney[0] + Bet;
    YourMoney[1] = "$" + str(YourMoney[0])
    print('');
    print('Your Current Balance is now ' + YourMoney[1]);
    print('');
  WhileKeep1 = 0
  WhileBreakHit3 = 1;
  WhileBreakHit4 = 1;
  WhileBreakCheckWin = 0;
  WhileBreakPlayGame = 1;
  while WhileKeep1 != 1:
    if WhileBreakCheckWin == 1:
      break;
    else:
      if YourMoney[0] <= 0:
        print('You can no longer play because you are broke. ( ͡° ͜ʖ ͡°)');
        WhileBreakCheckWin = 1;
        break;
      StateAgain = input('Play Again? *yes* or *no* - ')
      if StateAgain == "yes":
        WhileKeep1 = 1;
        PlayGame();
        break;
      elif StateAgain == "no":
        WhileKeep1 = 1;
        break;
      elif StateAgain == 'help':
        help();
      elif StateAgain == 'exit':
        break;
      else:
        print('Idiot.');
#Help Command
def help():
  replit.clear();
  Welcome();
  print();
  print('__How to play BlackJackLeetSauce__');
  print('Goal: Get a total 21 or as close to it without going over (based upon sum of cards in hand).');
  print('Once the game has begun the dealer will deal two cards to you and two to themself. You can either *hit* or *stand*.');
  print('*hit* - Draws another card to increase your current sum');
  print('*stand* - Keeps your hand and waits if you beat the dealer.');
  print('After you and the dealer finished your turns, the cards will be shown with a winner.');
  print('Warning: If you type *no* to not play again, you may need to type *no* multiple times.  It is a bug, you may also type *exit* at any time to exit the loops if necessary.');
#This is what runs the Code
UserInput = '';
while UserInput != 'exit':
  UserInput = input('')
  if UserInput == 'play':
    resetDeck();
    PlayGame();
  elif UserInput == 'help':
    help();